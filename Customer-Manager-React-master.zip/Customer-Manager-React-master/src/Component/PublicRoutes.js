// import React from "react";
// import { Navigate } from "react-router-dom";
// import { Login } from "./auth";

// const PublicRoutes = ({ component: Component, ...rest }) => {
//   console.log("okoko")
//   if (Login()) {
//     console.log("okoko1")
//     return <Navigate to="/App" />;
//   }
//   return <Component {...rest} />;
// };

// export default PublicRoutes;